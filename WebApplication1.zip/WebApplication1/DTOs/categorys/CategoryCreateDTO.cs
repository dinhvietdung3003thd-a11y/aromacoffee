﻿namespace WebApplication1.DTOs.categorys
{
    public class CategoryCreateDTO
    {
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
    }
}
