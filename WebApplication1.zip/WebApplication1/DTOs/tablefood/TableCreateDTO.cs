﻿namespace WebApplication1.DTOs.tablefood
{
    public class TableCreateDTO
    {
        public string Name { get; set; } = string.Empty;
        public string Status { get; set; } = "Trống";
    }
}
