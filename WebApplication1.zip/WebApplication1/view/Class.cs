﻿namespace WebApplication1.view
{
    public class Class
    {
    }
}
