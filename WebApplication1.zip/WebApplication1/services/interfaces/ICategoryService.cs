﻿using WebApplication1.DTOs.categorys;
namespace WebApplication1.services.interfaces
{
    public interface ICategoryService : IBaseService<CategoryDTO> { }
}


