﻿using WebApplication1.DTOs.product;
using WebApplication1.services.interfaces;
namespace WebApplication1.services.interfaces
{
    public interface IProductService : IBaseService<ProductDTO> { }
}


